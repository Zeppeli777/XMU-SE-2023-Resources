;x86（32位）汇编语言程序      冒泡法      降序排列           

    .486                                    			; 创建32位代码
    .model flat, stdcall                    		; 32位内存模型
    option casemap :none                    		; 区分大小写 
    include \masm32\macros\macros.asm       	
    includelib \masm32\lib\masm32.lib
    includelib \masm32\lib\gdi32.lib
    includelib \masm32\lib\user32.lib
    includelib \masm32\lib\kernel32.lib
    includelib \masm32\lib\wsock32.lib
    includelib \masm32\lib\msvcrt.lib
    include \masm32\include\msvcrt.inc
    include \masm32\include\masm32.inc
    include \masm32\include\gdi32.inc
    include \masm32\include\user32.inc
    include \masm32\include\kernel32.inc

.data								
    ; 10个原始数据，修改为了不同的值，排好后，还放在这里    
    arr dd 14, 3, 9, 2, 11, 7, 13, 5, 4, 8  
    len1 byte ? 						
    len2 byte ? 						
    fmt byte '%d ',0

.code
main:        ;-------------------显示原始数据----------------------------
    ; 获取数据长度
    mov len1,lengthof arr                         
    ; 获取数据的起始地址
    mov ebx,offset arr                              
    xor ecx,ecx
    mov al,len1
prt1:	
    movsx ebx,al
    cmp ecx,ebx
    jnb fina1
    ; 取出当前要显示的数据
    mov edx, arr[(type arr)*ecx]
    pushad
    ; 调用函数显示一个数据
    invoke crt_printf,offset fmt,edx             
    popad
    inc ecx
    jmp prt1
fina1:
    ; 显示回车、换行           
    print chr$(" ",13,10)                                 
    print chr$(" ",13,10)                                 

;----------------------------------------------排序--------------------
    ; 数据长度  ->  len1
    mov len1,lengthof arr                           
    ; 数据偏移地址(首地址)  ->   ebx
    mov ebx,offset arr                                 
    ; al初始化为0
    mov al,0h                                              
lp:	
    cmp al,len1
    jnb done                                               ; 排序结束，转done				

    ; ah初始化为1
    mov ah, 1h	                             
inner:				
    ; cl赋值为数据长度len1
    mov cl,len1                                          
    ; len2赋值为cl（即数据长度）
    mov len2,cl                                          
    ; len2 = len2 - al
    sub len2,al                                           
    cmp ah,len2                                         ; 比较ah 和 len2
    jnb last                                                 ; 跳出内循环
    ; esi赋值为ah
    movsx esi,ah 		            
    ; bl赋值为ah
    mov bl,ah                                           
    ; bl = bl - 1
    sub bl,1                                              
    ; edi赋值为bl
    movsx edi,bl                                      
    ; ecx赋值为arr[esi]
    mov ecx, arr[(type arr)*esi]                
    ; edx赋值为arr[edi]
    mov edx, arr[(type arr)*edi]               
    cmp ecx,edx                                       ;比较ecx和edx
    jb follow 		          	           ;小于则转                    降序排序   从大到小	
    ; edx赋值为arr[esi]
    mov edx,arr[(type arr)*esi]                
    ; edx与arr[edi]交换
    xchg edx,arr[(type arr)*edi]               
    ; edx与arr[esi]交换
    xchg edx,arr[(type arr)*esi]               
follow:	
    ; ah = ah + 1
    inc ah 	                                         
    jmp inner                                          ; 转内循环
last:	
    ; al = al + 1
    inc al                                                 
    jmp lp                                               ;转外循环

;----------------------------------显示排序后的数据------------------------
done:	
    xor ecx,ecx                                     
    mov al,len1
prt:	
    movsx ebx,al
    cmp ecx,ebx
    jnb fina
    mov edx, arr[(type arr)*ecx]
    pushad
    invoke crt_printf,offset fmt,edx
    popad
    inc ecx
    jmp prt
fina:	
    exit

end main 		