;x86（32位）汇编语言程序        冒泡法         升序排列            

    .486                                    			; create 32 bit code
    .model flat, stdcall                    		; 32 bit memory model
    option casemap :none                    		; case sensitive 
    include \masm32\macros\macros.asm       	
    includelib \masm32\lib\masm32.lib
    includelib \masm32\lib\gdi32.lib
    includelib \masm32\lib\user32.lib
    includelib \masm32\lib\kernel32.lib
    includelib \masm32\lib\wsock32.lib
    includelib \masm32\lib\msvcrt.lib
    include \masm32\include\msvcrt.inc
    include \masm32\include\masm32.inc
    include \masm32\include\gdi32.inc
    include \masm32\include\user32.inc
    include \masm32\include\kernel32.inc

.data								
    ; 修改为新的10个原始数据，排好序后仍放在这里
    arr dd 12, 3, 8, 1, 10, 5, 7, 2, 9, 4  
    len1 byte ? 						
    len2 byte ? 						
    fmt byte '%d ',0

.code
main:        ;-------------------显示原始数据----------------------------
    ; 获取数据的长度
    mov len1,lengthof arr                         
    ; 获取数据的起始内存偏移地址
    mov ebx,offset arr                              
    xor ecx,ecx
    mov al,len1
prt1:	
    movsx ebx,al
    cmp ecx,ebx
    jnb fina1
    ; 取出当前位置的数据到edx
    mov edx, arr[(type arr)*ecx]
    pushad
    ; 调用函数打印当前数据
    invoke crt_printf,offset fmt,edx             
    popad
    inc ecx
    jmp prt1
fina1:
    ; 打印回车和换行符，起到换行的效果
    print chr$(" ",13,10)                                 
    print chr$(" ",13,10)                                 

;----------------------------------------------排序--------------------
    ; 将数据长度存入len1
    mov len1,lengthof arr                           
    ; 将数据的首地址存入ebx
    mov ebx,offset arr                                 
    ; 初始化外层循环计数器al为0
    mov al,0h                                              
lp:	
    cmp al,len1
    jnb done                                               ; 排序结束，跳转到done				

    ; 初始化内层循环计数器ah为1
    mov ah, 1h	                             
inner:				
    ; 将数据长度存入cl
    mov cl,len1                                          
    ; 将cl的值存入len2
    mov len2,cl                                          
    ; 计算内层循环的剩余次数，存入len2
    sub len2,al                                           
    cmp ah,len2                                         ; 比较ah 和 len2
    jnb last                                                 ; 跳出内循环
    ; 将ah的值扩展为32位存入esi
    movsx esi,ah 		            
    ; 将ah的值存入bl
    mov bl,ah                                           
    ; bl的值减1
    sub bl,1                                              
    ; 将bl的值扩展为32位存入edi
    movsx edi,bl                                      
    ; 将arr[esi]的值存入ecx
    mov ecx, arr[(type arr)*esi]                
    ; 将arr[edi]的值存入edx
    mov edx, arr[(type arr)*edi]               
    cmp ecx,edx                                       ;比较ecx和edx
    jnb follow 		           ;大于等于则转           升序排列，从小到大	
    ; 将arr[esi]的值存入edx
    mov edx,arr[(type arr)*esi]                ;edx <- [esi]
    ; 交换edx和arr[edi]的值
    xchg edx,arr[(type arr)*edi]               ;edx与[edi]交换
    ; 再次交换，确保数据正确交换
    xchg edx,arr[(type arr)*esi]               ;edx与[esi]交换
follow:	
    ; ah的值加1
    inc ah 	                                         
    jmp inner                                          ; 跳转到内层循环
last:	
    ; al的值加1
    inc al                                                 
    jmp lp                                               ;跳转到外层循环

;----------------------------------显示排序后的数据------------------------
done:	
    xor ecx,ecx                                     
    mov al,len1
prt:	
    movsx ebx,al
    cmp ecx,ebx
    jnb fina
    mov edx, arr[(type arr)*ecx]
    pushad
    invoke crt_printf,offset fmt,edx
    popad
    inc ecx
    jmp prt
fina:	
    exit

end main 				